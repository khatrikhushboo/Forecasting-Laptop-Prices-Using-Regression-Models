This code sklearn and pytorch. The only non standard library required is mlxtend which can be installed using !pip install mlxtend. 

Please run the code from top to bottom, because variables are overwritten. You might run into an error if you just run random cells in between. 